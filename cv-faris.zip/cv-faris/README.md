# CV — M. Faris Tiandika

Situs CV/portofolio pribadi. Struktur: Home, About, Projects, Pendidikan, Sertifikat, Kontak.

## Cara pakai (lokal)

Buka `index.html` langsung di browser, atau pakai extension "Live Server" di VS Code.

## Isi sebelum publish

1. **Foto diri** — simpan sebagai `assets/img/foto-diri.jpg`
2. **Preview 3 proyek** — simpan sebagai:
   - `assets/img/project-website.jpg`
   - `assets/img/project-topup.jpg`
   - `assets/img/project-terranusa.jpg`
   (screenshot tampilan tiap situs, disarankan ukuran ~800x500px)
3. **File CV (PDF)** — simpan sebagai `assets/cv-faris-tiandika.pdf` (dipakai tombol "Unduh CV")
4. **Link kontak** — buka `index.html`, cari bagian `<section id="contact">`, ganti:
   - `you@example.com` → email kamu
   - `your-username` (3 tempat: GitHub, Instagram, LinkedIn) → username asli kamu

Kalau gambar belum ada, situs tetap tampil rapi — bagian foto/preview otomatis muncul sebagai kotak placeholder bertuliskan "Foto diri" / "Preview situs".

## Hosting di GitHub Pages (gratis)

1. Buat repository baru di GitHub, misalnya `cv-faris` (bisa public).
2. Upload semua isi folder ini (`index.html`, `style.css`, `script.js`, folder `assets`) ke repo tersebut — lewat web GitHub (drag & drop) atau lewat git:
   ```
   cd cv-faris
   git init
   git add .
   git commit -m "Situs CV pertama"
   git branch -M main
   git remote add origin https://github.com/USERNAME/cv-faris.git
   git push -u origin main
   ```
3. Di halaman repo GitHub, buka **Settings → Pages**.
4. Di bagian **Build and deployment → Source**, pilih **Deploy from a branch**.
5. Pilih branch **main** dan folder **/ (root)**, lalu klik **Save**.
6. Tunggu 1–2 menit, situs akan aktif di:
   `https://USERNAME.github.io/cv-faris/`

Kalau mau pakai nama repo `USERNAME.github.io` (bukan `cv-faris`), situsnya langsung jadi domain utama kamu: `https://USERNAME.github.io/`.
